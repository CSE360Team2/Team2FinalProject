# Team2FinalProject

This is a java application intended to provide a quiz user interface, in which a pre-exit .csv file with the quiz information will be 
loaded. The software is able to monitor the score and elapsed time, and a ghost companion will react according to that.

Instruction:
1. The user shall type in a valid user name and click enter on login page
2. The user can click exit button to leave the quiz
3. After pressing the start button, the user can choose one answer for each question
4. The ghost character will behave according to current score and time been used.

last updated: 7/7/2017
